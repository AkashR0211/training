package com.stackroute.streams;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FileOperationsUsingStreams {
    public int getUniqueWordCount(String fileName) throws IOException {
        if (fileName == null || fileName.trim().isEmpty() || !fileName.endsWith(".txt")) {
            return 0;
        }

        try (Stream<String> lines = Files.lines(Paths.get(fileName))) {
            return lines
                    .flatMap(line -> Arrays.stream(line.split("\\s+")))
                    .filter(word -> !word.isEmpty())
                    .collect(Collectors.toSet())
                    .size();
        } catch (IOException e) {
            return 0;
        }
    }
    public Set<String> getWordListWithoutDuplicates(String fileName) throws IOException {
        if (fileName == null || fileName.trim().isEmpty() || !fileName.endsWith(".txt")) {
            return Collections.emptySet();
        }
        try (Stream<String> lines = Files.lines(Paths.get(fileName))) {
            return lines
                    .flatMap(line -> Arrays.stream(line.split("\\s+")))
                    .filter(word -> !word.isEmpty())
                    .collect(Collectors.toSet());
        } catch (IOException e) {
            return Collections.emptySet();
        }
    }

    public List<String> getWordListInUppercaseExcludingFirstLine(String fileName) throws IOException {
        if (fileName == null || fileName.trim().isEmpty() || !fileName.endsWith(".txt")) {
            return Collections.emptyList();
        }

        try (Stream<String> lines = Files.lines(Paths.get(fileName))) {
            return lines
                    .skip(1)
                    .flatMap(line -> Arrays.stream(line.split("\\s+")))
                    .map(String::toUpperCase)
                    .filter(word -> !word.isEmpty())
                    .collect(Collectors.toList());
        } catch (IOException e) {
            return Collections.emptyList();
        }
    }

    public String getEachWordsSeparatedByColon(String fileName) throws IOException {
        if (fileName == null || fileName.trim().isEmpty() || !fileName.endsWith(".txt")) {
            return null;
        }

        try (Stream<String> lines = Files.lines(Paths.get(fileName))) {
            return lines
                    .flatMap(line -> Arrays.stream(line.split("\\s+")))
                    .filter(word -> !word.isEmpty())
                    .collect(Collectors.joining(":"));
        } catch (IOException e) {
            return null;
        }
    }

    public String getEachLineSeparatedByComma(String fileName) throws IOException {
        if (fileName == null || fileName.trim().isEmpty() || !fileName.endsWith(".txt")) {
            return null;
        }

        try (Stream<String> lines = Files.lines(Paths.get(fileName))) {
            return lines
                    .collect(Collectors.joining(","));
        } catch (IOException e) {
            return null;
        }
    }

    public Optional<Integer> getMaxOfIntegers(String fileName) throws IOException {
        if (fileName == null || fileName.trim().isEmpty() || !fileName.endsWith(".txt")) {
            return Optional.empty();
        }

        try (Stream<String> lines = Files.lines(Paths.get(fileName))) {
            return lines
                    .flatMap(line -> Arrays.stream(line.split("\\s+")))
                    .filter(word -> word.matches("\\d+"))
                    .map(Integer::parseInt)
                    .max(Integer::compareTo);
        } catch (IOException e) {
            return Optional.empty();
        }
    }

    public Optional<Integer> getSumOfIntegers(String fileName) throws IOException {
        if (fileName == null || fileName.trim().isEmpty() || !fileName.endsWith(".txt")) {
            return Optional.empty();
        }

        try (Stream<String> lines = Files.lines(Paths.get(fileName))) {
                int sum = lines
                        .flatMap(line -> Arrays.stream(line.split("\\s+")))
                        .filter(word -> word.matches("\\d+"))
                        .mapToInt(Integer::parseInt)
                        .sum();

                // Return Optional.empty() if the sum is 0 and no integers were found
                return sum == 0 ? Optional.empty() : Optional.of(sum);
        } catch (IOException e) {
            return Optional.empty();
        }
    }
}

