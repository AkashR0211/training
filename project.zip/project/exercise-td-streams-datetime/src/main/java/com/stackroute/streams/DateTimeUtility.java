package com.stackroute.streams;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class DateTimeUtility {
    public List<String> getNextMonthWorkingDays(LocalDate date) {
        List<String>workingDays= new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate firstDayOfNextMonth=date.plusMonths(1).withDayOfMonth(1);

        int totalDays= firstDayOfNextMonth.lengthOfMonth();

        for (int i=0;i<totalDays;i++){
            LocalDate currentDay= firstDayOfNextMonth.plusDays(i);
            if(currentDay.getDayOfWeek().getValue()<6){
                workingDays.add(currentDay.format(formatter));
            }
        }

        return workingDays;


    }

    public List<String> getScheduledBusDepartureTimings(String startTime, Duration frequency) {
        List<String> departureTimings = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        LocalTime currentTime = DateTimeFormatter.ofPattern(startTime);


    return null;
    }

}
