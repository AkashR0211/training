package com.stackroute.streams;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class StreamCollectorsUtilityTest {
    private StreamCollectorsUtility streamCollectorsUtility;
    private List<Integer> integerList;

    @BeforeEach
    void setup(){
        streamCollectorsUtility = new StreamCollectorsUtility();

    }


    @Test
    public void listOfSquaresOfOddNumbersAndMultipleOfThreeForGivenRange() {
        integerList = List.of(1,4,3,5,7,8,9,13,12,15);
        List<Integer> expectedResult=List.of(9,81,225);
        assertEquals(expectedResult,streamCollectorsUtility.getOddSquaresOfMultiplesOfThree(3,15));


    }
    @Test
    void testForInvalidRange() {

        List<Integer> expectedResult = Collections.emptyList();
        assertEquals(expectedResult, streamCollectorsUtility.getOddSquaresOfMultiplesOfThree(15, 3));
    }

    @Test
    void EvenMultiplesOfFive(){
        List<Integer> expectedResult =List.of(0,10);
        assertEquals(expectedResult,streamCollectorsUtility.getEvenMultiplesOfFive(10));


    }
}
