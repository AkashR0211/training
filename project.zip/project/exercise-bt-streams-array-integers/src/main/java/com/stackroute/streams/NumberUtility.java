package com.stackroute.streams;

import java.util.Arrays;
import java.util.Optional;
import java.util.OptionalDouble;

/**
 * Utility class for operations on elements of array
 */
public class NumberUtility {

    /**
     * Returns sum of even numbers from the array
     * Returns 0, if there are no even numbers or if the passed array is null
     */
    public long getSumOfEven(int[] numbers) {
        if(numbers==null || numbers.length==0) return 0;

        return Arrays.stream(numbers).filter(i->i%2==0).sum();
    }

    /**
     * Returns average of all the integers as  optionalDouble from given array
     * Returns Empty Optional, if the given array is null or empty
     */
    public OptionalDouble getAverageOfOdd(int[] numbers) {
        if(numbers==null || numbers.length==0) return OptionalDouble.empty();

        return Arrays.stream(numbers).asDoubleStream().filter(i->i%2==1).average();
    }

    /**
     * Returns product of all numbers
     * Returns 0 if the array is null or empty
     */
    public long getProduct(int[] numbers) {
        if(numbers==null || numbers.length==0) return 0;
        return Arrays.stream(numbers).asLongStream().reduce(1,(a,b)->a*b);
    }

}