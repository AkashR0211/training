package com.stackroute.collections;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/*
This class contains a property called movieMap of type Map
This class contains methods for adding key-value pairs of Movie and its rating to HashMap and
various methods for accessing the keys and values based on some conditions
 */
public class MovieService {

    /**
     * Constructor to create movieMap as an empty  LinkedHashMap object
     */

    public MovieService() {
    }

    /*
    Returns the movieMap object
     */
    Map<Movie,Integer> movieMap= new LinkedHashMap<>();
    public Map<Movie, Integer> getMovieMap() {

        return movieMap;
    }

    /*
    Add key-value pairs of Movie-Integer type and returns Set of Map.Entry
     */
    public Set<Map.Entry<Movie, Integer>> addKeyValuePairsToMap(Movie movie, Integer rating) {

        movieMap.put(movie, rating);
        return movieMap.entrySet();

    }

    /*
    Return Set of movie names having rating greater than or equal to given rating
     */
    public List<String> getHigherRatedMovieNames(int rating) {
        return movieMap.entrySet().stream().filter(movie->movie.getValue()>=rating)
                .map(movie-> movie.getKey().getMovieName()).sorted()
                .collect(Collectors.toList());

    }

    /*
    Return Set of movie names belonging to specific genre
     */
    public List<String> getMovieNamesOfSpecificGenre(String genre) {

        return movieMap.entrySet().stream()
                .filter(Genre -> Genre.getKey().getGenre().equalsIgnoreCase(genre))
                .map(movie-> movie.getKey().getMovieName())
                .collect(Collectors.toList());
    }

   /*
   Return Set of movie names which are released after Specific releaseDate and having rating less than or equal to 3
    */

    public List<String> getMovieNamesReleasedAfterSpecificDateAndRatingLesserThanThree(LocalDate releaseDate) {
        return movieMap.entrySet().stream()
                .filter(movie -> movie.getKey().getReleaseDate().isAfter(releaseDate) && movie.getValue() <= 3)
                .map(movie -> movie.getKey().getMovieName())
                .toList();
    }
    /*
    Return set of movies sorted by release dates in ascending order.
    Hint: Use TreeMap
     */
    public List<Movie> getSortedMovieListByReleaseDate() {

        return new TreeMap<>(movieMap).keySet().stream().toList();
    }

    /*
   Return set of movies sorted by rating.
   Hint: Use Comparator and LinkedHashMap
    */
    public Map<Movie, Integer> getSortedMovieListByRating() {
        return movieMap.entrySet().stream()
                .sorted(Map.Entry.comparingByValue())
                .collect(LinkedHashMap::new, (map, entry) -> map.put(entry.getKey(),entry.getValue()),LinkedHashMap::putAll );
    }
}
