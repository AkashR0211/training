package com.stackroute.streams;

import java.util.List;

public class AverageFinder {
    //write logic to find the average of given list of integers
    public String findAverage(List<Integer> input) {
        if(input==null) return"Give proper input not null";
        if(input.isEmpty()) return "Give proper input not empty list";

        int length =input.size();
        double avg= (double) (input.stream().reduce(0, Integer::sum))/length;

        return  "Average of given list of integers is "+ avg;

    }
}
