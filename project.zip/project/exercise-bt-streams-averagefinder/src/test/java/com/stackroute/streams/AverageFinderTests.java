package com.stackroute.streams;

import org.junit.jupiter.api.*;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertNotNull;


public class AverageFinderTests {
    private AverageFinder averageFinder;

    private static final String MESSAGE = "Check the logic of the method findAverage";
    private static final String NULL_MESSAGE = "Check whether input is null or not in the method findAverage";
    private static final String EMPTY_MESSAGE = "Check whether input is empty or not in the method findAverage";

    @BeforeEach
    public void setUp() {
        averageFinder = new AverageFinder();
    }

    @AfterEach
    public void tearDown() {
        averageFinder = null;
    }

    @Test
    public void givenListOfIntegersThenReturnResult() {
        String output = "Average of given list of integers is 369.5";
        List<Integer> input = Arrays.asList(24, 232, 44, 148, 490, 544, 1000, 474);
        assertEquals(output, averageFinder.findAverage(input), MESSAGE);
    }

    @Test
    public void givenListOfNegativeIntegersThenReturnResult() {
        String output = "Average of given list of integers is -310.75";
        List<Integer> input = Arrays.asList(-24, -232, -44, -148, -490, -544, -1000, -4);
        assertEquals(output, averageFinder.findAverage(input), MESSAGE);
    }

    @Test
    public void givenListAsNullThenReturnErrorMessage() {
        String output = "Give proper input not null";
        assertEquals(output, averageFinder.findAverage(null),NULL_MESSAGE);
    }

    @Test
    public void givenEmptyListThenReturnErrorMessage() {
        String output = "Give proper input not empty list";
        assertEquals(output, averageFinder.findAverage(Arrays.asList()), EMPTY_MESSAGE);
    }

    @Test
    public void givenInputsThenReturnResultNotNull() {
        assertNotNull(averageFinder.findAverage(Arrays.asList(2343, 432, 3, -24, 656, -878, 78, -2, 23)), MESSAGE);
    }

}
