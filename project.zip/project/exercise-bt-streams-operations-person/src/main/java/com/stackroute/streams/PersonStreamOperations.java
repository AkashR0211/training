package com.stackroute.streams;

import java.util.*;
import java.util.stream.Collectors;

/**
 * This class has various methods to do stream operations on person collection
 */
public class PersonStreamOperations {

    /**
     * sorts the person list alphabetically in uppercase
     * Returns Empty Optional if the given list is null or empty
     *
     *
     */
    public Optional<List<String>> getPersonListSortedByNameInUpperCase(List<String> personList) {
        if (personList==null || personList.isEmpty()){
            return  Optional.empty();
        }
        var sorted= personList.stream()
                .filter(p-> !p.trim().isEmpty())
                .sorted(String::compareToIgnoreCase)
                .map(String::toUpperCase)
                .toList() ;

        return Optional.of(sorted);
    }

    /**
     * Sorts the distinct person names in descending order
     * Returns empty set if the given list is empty or null
     *
     *
     */

    public Set<String> getDistinctPersonNamesSortedInDescendingOrder(List<String> personList) {
        if (personList==null || personList.isEmpty()){
            return  Collections.emptySet();
        }

        return personList.stream()
                .filter(p->p!= null && !p.trim().isEmpty())
                .sorted(Comparator.reverseOrder())
                .collect(Collectors.toCollection(LinkedHashSet::new));
    }

    /**
     * Returns "Person found" if the person searched is available in the list or else returns "Person not found"
     * Returns "Give proper input not null" if the given list or name to search is null
     *
     *
     */
    public String searchPerson(List<String> personList, String nameToSearch) {
        if(personList==null|| nameToSearch==null){
            return  "Give proper input not null" ;
        }

        boolean value = personList.stream().anyMatch(name -> name.equalsIgnoreCase(nameToSearch));


        return value ? "Person found": "Person not found";
    }

    /**
     * Filters the list whose name length is greater than five and sorts by name length
     * Returns empty list if the given list is empty or null
     *
     *
     */

    public List<String> getPersonListSortedByLengthWithNameLengthGreaterThanFive(List<String> personList) {
        if(personList==null || personList.isEmpty()){
            return List.of();
        }

        return personList.stream()
                .filter(name-> name.length()>5)
                .sorted(Comparator.comparingInt(String::length))
                .toList();

    }


    /**
     * Returns the person name having maximum age from the given Map<String,Integer> having name as key and age as value
     * Returns "Give proper input not null" if the given map is empty or null
     *
     *
     *
     */

    public String getPersonByMaxAge(Map<String, Integer> personMap) {
        if (personMap== null || personMap.isEmpty()) {
            return "Give proper input not null";
        }
        Optional<Map.Entry<String,Integer>> maxEntry = personMap.entrySet().stream().max(Map.Entry.comparingByValue());


        return maxEntry.map(Map.Entry::getKey).orElse("Give proper input not null");
    }

}
