package com.stackroute.lambdaexpressions;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;


import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;


public class LambdaExpressionDemoTests {
    private LambdaExpressionsDemo lambdaExpressionsDemo;

    @BeforeEach
    void setup(){
        lambdaExpressionsDemo= new LambdaExpressionsDemo();
    }
    @Test
    void withValidListOfIntegerValuesAndDividend(){
        List<Integer> integers= Arrays.asList(2,3,4,6,7,-5);
        Integer dividend =20;
        List<Integer> result= lambdaExpressionsDemo.arithmeticOperation(integers,dividend);
        assertEquals(Arrays.asList(10,6,5,3,2,-4),result);
    }

    @Test
    void withListOfIntegersContainingZeroAndDividend(){
        List<Integer> integers =Arrays.asList(-0,5,3);
            Integer dividend = 50;
            assertThrows(RuntimeException.class,()->lambdaExpressionsDemo.arithmeticOperation(integers,dividend));
    }

    @Test
    void withNullListAndNullDividend(){
        List<Integer>integers = null;
        Integer dividend= null;
        assertThrows(NullPointerException.class, ()->lambdaExpressionsDemo.arithmeticOperation(integers,dividend));
    }

    @Test
    void withListOfStringValuesWithOffsetIs0(){
        List<String> names=Arrays.asList("Akash","Dhruv","Vikram");
        int offset=0;
        List<String> result = lambdaExpressionsDemo.writeToFile(offset,names);

        assertEquals(Arrays.asList("file1.txt","file2.txt","file3.txt"),result);

    }

    @Test
    void withListOfStringValuesWithOffsetIs10(){
        List<String> names=Arrays.asList("Akash","Dhruv","Vikram");
        int offset= 10;
        assertThrows(RuntimeException.class,()->lambdaExpressionsDemo.writeToFile(offset,names));

    }
    @Test
    void withListOfStringValuesWithOffsetLessThanZero() {
        List<String> names = Arrays.asList("Akash", "Dhruv", "Vikram");
        int offset = -1;
        assertThrows(RuntimeException.class, () -> lambdaExpressionsDemo.writeToFile(offset, names));
    }
    @Test
    void withNullListandOffset(){
        List<String>names = null;
        int offset=-1;
        assertThrows(NullPointerException.class,()->lambdaExpressionsDemo.writeToFile(offset,null));
    }
    @Test
    void withNullListandOffsetis10(){
        List<String>names = null;
        int offset=10;
        assertThrows(NullPointerException.class,()->lambdaExpressionsDemo.writeToFile(offset,names));
    }
    @Test
    void withEmptyListAndOffsetLessThanZero(){
        List<String>names = Arrays.asList("");
        int offset=-1;
        assertThrows(RuntimeException.class,()->lambdaExpressionsDemo.writeToFile(offset,names));

    }

    @Test
    void withEmptyListAndOffset() {
        List<String> names = Collections.emptyList();
        int offset = 20;
        List<String> result = lambdaExpressionsDemo.writeToFile(offset, names);
        assertEquals(Collections.emptyList(), result);

    }
}

