package service;

import exception.CountryNotFoundException;
import model.Batsman;

import java.util.*;
import java.util.stream.Collectors;

public class BatsmanService {

    public Optional<Batsman> getBatsman(List<Batsman> batsmanList, String name, String countryCode) throws CountryNotFoundException {
        if(batsmanList==null||batsmanList.isEmpty()|| name ==null|| name.isEmpty()||countryCode==null|| countryCode.isEmpty())
            return Optional.empty();
        boolean countryExists = batsmanList.stream().anyMatch(batsman -> batsman.getCountry().getCountryCode().equalsIgnoreCase(countryCode));
        if(!countryExists) throw new CountryNotFoundException("Country with "+ countryCode+" doesn't exists" );

        return batsmanList.stream()
                .filter(batsman -> batsman.getName().equalsIgnoreCase(name)&&batsman.getCountry().getCountryCode().equalsIgnoreCase(countryCode))
                .findAny();
    }

    public String getBatsmanNamesForCountry(List<Batsman> batsmanList, String countryCode) {
        if(batsmanList==null||batsmanList.isEmpty()||countryCode==null|| countryCode.isEmpty())
            return null;
        List<String> name = batsmanList.stream()
                .filter(batsman -> batsman.getCountry().getCountryCode().equalsIgnoreCase(countryCode))
                .map(Batsman::getName).sorted().toList();

        return "["+ String.join("," , name)+ "]";


    }

    public Map<String, Integer> getPlayerNameWithTotalRuns(List<Batsman> batsmanList) {
        if(batsmanList==null||batsmanList.isEmpty())
            return Collections.emptyMap();

        return batsmanList.stream().filter(batsman -> batsman.getMatchesPlayed()>50)
                .collect(Collectors.toMap(Batsman::getName,Batsman::getTotalRuns));
    }


    public Integer getHighestRunsScoredByBatsman(List<Batsman> batsmanList, String country) {
        if(batsmanList == null || batsmanList.isEmpty() || country==null||country.isEmpty())
            return 0;
        return batsmanList.stream()
                .filter(batsman -> batsman.getCountry().getName().equalsIgnoreCase(country))
                .map(Batsman::getHighestScore)
                .max(Integer::compareTo)
                .orElse(0);

    }


    public Optional<List<String>> getPlayerNamesByCountry(List<Batsman> batsmanList, String country) {
        if(batsmanList == null || batsmanList.isEmpty() || country==null||country.isEmpty())
            return Optional.empty();
        List<String> names =batsmanList.stream()
                .filter(batsman -> batsman.getCountry().getName().equalsIgnoreCase(country))
                .filter(batsman -> batsman.getTotalRuns()>5000)
                .map(Batsman::getName)
                .sorted(Comparator.reverseOrder())
                .collect(Collectors.toCollection(LinkedList::new));
        return names.isEmpty()? Optional.empty():Optional.of(names);

    }

}
